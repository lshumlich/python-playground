

from datetime import datetime
from src.util.appdate import prod_month_to_date

print(prod_month_to_date(201511))
