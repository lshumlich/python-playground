import xml

import xml.etree.ElementTree as ET

tree = ET.parse('\\$temp\\xml\\Sample-FACILITY.xml')
# tree = ET.parse('\\$temp\\xml\\Sample-VOLUMETRIC.xml')

root = tree.getroot()

# print ('---Tag-->', root.tag)
# print('----attr->', root.attrib)
#
# for c in root.iter():
#     print(c.tag, " - ", c.attrib, c.text, ' - ' )


class CommonData():
    eDocument = {}
    eRow = {}
    column_count = 0
    dot_notation = []
    data = []


def showStruc(element, level):
    for child in element:
        if '}' in child.tag:
            tag = child.tag.split('}', 1)[1]  # strip all namespaces
        else:
            tag = child.tag

        if len(cd.dot_notation) <= level:
            cd.dot_notation.append("")

        cd.dot_notation[level] = tag
        fulltag = ""
        for i in range(level+1):
            fulltag += '.' + cd.dot_notation[i]

        print(level, ' - ', fulltag, " Tag-> ", tag, "Child-> ", child.attrib, child.text)

        if fulltag not in cd.eDocument:
            # print("   new element: ", fulltag, cd.column_count)
            cd.eDocument[fulltag] = cd.column_count
            cd.column_count += 1
        if fulltag not in cd.eRow:
            cd.eRow[fulltag] = cd.column_count
            cd.data.append(child.text)
        else:
            print("---> output row: ", cd.data)


        showStruc(child, level + 1)

cd = CommonData()

showStruc(root, 0)

# for child in root:
#     print("Tag-> ", child.tag, "Child-> ", child.attrib)
#     # r = child.getroot()
#     # print ("r-->", r.tag)
#     for c in child:
#         print("T-> ", c.tag, "C- > ", c.attrib)


