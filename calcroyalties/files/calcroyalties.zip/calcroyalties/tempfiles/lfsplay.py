import jinja2
import os
from itertools import groupby, tee

def test_render():
    # not quite working. It gives an error for __call__
    # assume it is an unittest function
    context = {  # your variables to pass to template
        'test_var': 'test_value',
        'url_for': 'lfsloc',
        '__call__': 'lfscall'
    }
    # path = 'path/to/template/dir'
    path = os.path.join(os.path.dirname(os.getcwd()), "src/app/templates/worksheet")
    print(os.listdir(path))
    print('-- the path: ', path)
    filename  ='calc_worksheet.html'

    rendered = jinja2.Environment(
        loader=jinja2.FileSystemLoader(path)
    ).get_template(filename).render(context)

    # `rendered` is now a string with rendered template
    # do some asserts on `rendered` string
    # i.e.
    assert 'test_value' in rendered

def test_render2():
    from jinja2 import Environment, PackageLoader
    env_name = 'C:/code/python-playground/calcroyalties/src/app'
    print(os.listdir(env_name))
    env = Environment(
        loader=PackageLoader(env_name, 'templates'))


# loader = PackageLoader(os.path.join(os.path.dirname(os.getcwd()), "src/app"), 'templates'))

def test_dir():
    print(os.path.join(os.path.dirname(os.getcwd()), "src/app"))
    print(os.listdir(os.path.join(os.path.dirname(os.getcwd()), "src/app")))
    print(__name__)
    print(__file__)
    print(os.listdir('.'))
    print(os.getcwd())
    print(os.path.dirname(os.getcwd()))
    print(os.pardir)
    print(__file__)
    print(os.path.join(os.path.dirname(__file__), "files/"))

def play1():
    my_list = ['Hello', 'World', 'I', 'Love', 'You']
    print(' and '.join(my_list))

def get_calc_list():
    print("Hello Calc List")
    import config
    db = config.get_database()
    statement = """SELECT * from calc, wellroyaltymaster,monthly
        where calc.wellid = wellroyaltymaster.id and
        calc.wellid = monthly.wellid  and
        calc.ProdMonth = monthly.ProdMonth and
        calc.Product = monthly.Product
        order by calc.prodMonth, calc.LeaseID, calc.wellid
    """
    result = db.select_sql(statement)
    print('we have found: ', len(result))
    return result

def group_by_test(results):

    for key, group in groupby(results, lambda x: str(x.ProdMonth) + str(x.LeaseID) + str(x.WellID) + x.Product):
        group1, group2 = tee(group)
        x = next(group1)
        print('key: ', x.ProdMonth, x.LeaseID, x.WellID, x.Product)

        for r in group2:
            print(' data: ', r.ProdMonth, r.WellID, x.Product)

        print('sum', x.ProdMonth, x.WellID)

    # for r in results:
    #     print(r.ProdMonth, r.Product, r.WellID,r.LeaseID,r.ProdVol)

def func(x):
    # print('-- func', x)
    return str(x.ProdMonth)

# test_render()
# test_render2()
# test_dir()
# play1()

results = get_calc_list()
group_by_test(results)