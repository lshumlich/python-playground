# from flask_testing import TestCase
import flask
from flask import Flask, Blueprint, request, config, render_template

# from src.app import app
# c = app.test_client()
# app = flask.Flask(__name__)
# render_template('worksheet/calc_worksheet.html', well='ASDF')

from flask import template_rendered
from contextlib import contextmanager

# @contextmanager
# def captured_templates(app):
#     render_template('worksheet/calc_worksheet.html', well='ASDF')
#
def play1():
    from src.app import app
    # app = Flask(__name__)
    client = app.test_client()

    response = render_template('worksheet/calc_worksheet.html', well='ASDF')
    # response = client.get('/')
    print(response)
    print(response.get_data())


def url_for(s1,filename=None):
    return 'url_for_was_called'

class Data():
    pass

def play2():
    # env = Environment(loader=PackageLoader('src.app', 'templates'))
    env = Environment(loader=PackageLoader('src.app', 'templates\\worksheet'))
    # template = env.get_template('layout.html')
    # template = env.get_template('index.html')
    template = env.get_template('calc_worksheet.html')
    well = Data()
    well.ID = 123
    m = Data()
    m.RPBA = 1234
    ba=Data

    print(template.render(url_for=url_for, well=well, m=m))


def play3():
    from jinja2 import Environment, PackageLoader
    from flask import url_for
    env = Environment(loader=PackageLoader('src.app', 'templates'))
    template = env.get_template('worksheet/calc_worksheet.html')
    print(url_for('static'))
    well = Data()
    well.ID = 123
    m = Data()
    m.RPBA = 1234
    ba=Data
    ba.CorpShortName = "Larry's Oil and Gas"

    print(template.render(url_for=url_for, well=well, ba=ba, m=m))


def play4():
    s = 'this isn\'t mine'
    print(s)
    s = s.replace('\'','\'\'')
    print(s)
    print('\'')

# play3()
play4()
